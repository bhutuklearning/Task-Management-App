import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import User from './models/User.js';

dotenv.config();

const createAdmin = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI + process.env.DATABASE_NAME, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useCreateIndex: true,
            useFindAndModify: false,
        });

        const adminExists = await User.findOne({ username: 'admin' });

        if (adminExists) {
            console.log('Admin user already exists');
            await mongoose.connection.close();
            return;
        }

        const hashedPassword = await bcrypt.hash('adminpassword', 10);

        const admin = new User({
            username: 'admin',
            email: 'admin@example.com',
            password: hashedPassword,
            role: 'admin'
        });


        await admin.save();
        console.log('Admin user created successfully');
        await mongoose.connection.close();
    } catch (error) {
        console.error('Error creating admin user:', error);
    }
};

createAdmin();