// tailwind.config.js
module.exports = {
    darkMode: 'class',
    theme: {
        extend: { /* your customizations */ }
    },
    variants: { extend: {} },
    plugins: []
}